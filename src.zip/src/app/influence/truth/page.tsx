export default function TruthPage() {
  return <h1>Truth Vault</h1>;
}
