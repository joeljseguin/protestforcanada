export default function MazePage() {
  return <h1>Maze Game</h1>;
}
