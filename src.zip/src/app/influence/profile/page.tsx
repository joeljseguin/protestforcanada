export default function ProfilePage() {
  return <h1>Civic Profile</h1>;
}
